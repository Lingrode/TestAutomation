function addition(a, b) {
  return a + b;
}

function substract(a, b) {
  return a - b;
}

function multiply(a, b) {
  return a * b;
}

function divide(a, b) {
  if (b === 0) {
    throw new Error("Division by zero is impossible");
  }

  return a / b;
}

module.exports = { addition, substract, multiply, divide };